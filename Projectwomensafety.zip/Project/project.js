// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCJrQpp1ZbSUPL_wIFl3uFkBz5IEEO7xZU",
  authDomain: "womensafety-53bf9.firebaseapp.com",
  databaseURL: "https://womensafety-53bf9-default-rtdb.firebaseio.com",
  projectId: "womensafety-53bf9",
  storageBucket: "womensafety-53bf9.appspot.com",
  messagingSenderId: "1027972515933",
  appId: "1:1027972515933:web:962094136904b7258e25b4",
  measurementId: "G-F4WC3EDYPT"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Reference your database
var contactFormDB = firebase.database().ref("contactForm");

document.getElementById("contactForm").addEventListener("submit", submitForm);

function submitForm(e) {
  e.preventDefault();

  var name = getElementVal("name");
  var emailid = getElementVal("emailid");
  var age = getElementVal("age");
  var gender = getElementVal("gender");
  var password = getElementVal("password");
  var phone = getElementVal("phoneno");
  var whatsapp = getElementVal("whatsapp");
  var msgContent = getElementVal("msgContent");
  var image = document.getElementById("image").files[0];

  // Save message
  saveMessages(name, emailid, age, gender, password, phone, whatsapp, msgContent, image);

  // Show alert
  document.querySelector(".alert").style.display = "block";

  // Remove alert after 3 seconds
  setTimeout(() => {
      document.querySelector(".alert").style.display = "none";
  }, 3000);

  // Reset the form
  document.getElementById("contactForm").reset();
}

// Save messages to Firebase
const saveMessages = (name, emailid, age, gender, password, phone, whatsapp, msgContent, image) => {
  var newContactForm = contactFormDB.push();

  // Store image in Firebase storage (if required)
  if (image) {
      var storageRef = firebase.storage().ref('images/' + image.name);
      storageRef.put(image).then(() => {
          storageRef.getDownloadURL().then((url) => {
              newContactForm.set({
                  name: name,
                  emailid: emailid,
                  age: age,
                  gender: gender,
                  password: password,
                  phone: phone,
                  whatsapp: whatsapp,
                  msgContent: msgContent,
                  imageURL: url
              });
          });
      });
  } else {
      newContactForm.set({
          name: name,
          emailid: emailid,
          age: age,
          gender: gender,
          password: password,
          phone: phone,
          whatsapp: whatsapp,
          msgContent: msgContent
      });
  }
};

// Function to get form values
const getElementVal = (id) => {
  return document.getElementById(id).value;
};

  